# -*- coding: utf-8 -*-
__author__ = 'Junior Lima'


PAGAMENTO_TIPO = (
    ('1', 'Dinheiro'),
    ('2', 'Transferência'),
    ('3', 'Cartão'),
    ('4', 'Cheque'),
)