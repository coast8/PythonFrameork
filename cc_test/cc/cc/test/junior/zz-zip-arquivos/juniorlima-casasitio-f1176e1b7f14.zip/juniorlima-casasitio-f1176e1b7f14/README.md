# README #

Documentação com todas as medidas necessárias para obter o aplicativo "CasaSitio" instalado e funcionando.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### Como faço para configurar? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Orientação de contribuição ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact

## Instale os pacotes

Instale os pacotes da aplicação

	pip install django==1.8.5
	pip install django-ckeditor==5.0.2
	pip install sorl-thumbnail==12.3
	pip install Pillow==3.0.0
	pip install django-suit==0.2.15
	pip install oauth2client
	pip install httplib2
	pip install yawd-admin
	pip install django-suit==0.2.15
	pip install django-suit==0.2.15