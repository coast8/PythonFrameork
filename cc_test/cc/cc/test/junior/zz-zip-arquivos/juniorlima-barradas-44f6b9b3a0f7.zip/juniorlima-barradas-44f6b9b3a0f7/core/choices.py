# -*- coding: utf-8 -*-
__author__ = 'juniorlima'

BLOG_POSTAGEM_POSICAO = (
    ('1', 'Padrão'),
    ('2', 'Imagem esquerda'),
    ('3', 'Imagem direita'),
)

PUBLICIDADES_TIPOS = (
    ('1','Imagem'),
    ('2','Flash'),
)

COLOR_CSS_CHOICES = (
    ('01', 'Vinho'),
    ('02', 'Verde'),
    ('03', 'Laranja'),
    ('04', 'Cinza'),
    ('05', 'Azul'),
    ('06', 'Roxo'),
    ('07', 'Marrom'),
    ('08', 'Rosa Leve'),
    ('09', 'Preta'),
)