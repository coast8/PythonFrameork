var SelectFilter = {
    init: function($a, $b, $c, $d) {  } //stub
};