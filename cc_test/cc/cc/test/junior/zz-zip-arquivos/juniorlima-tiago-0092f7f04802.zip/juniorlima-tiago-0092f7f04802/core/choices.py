from __future__ import unicode_literals
# -*- coding: utf-8 -*-
__author__ = 'Junior Lima'

STATUS_SOLICITACAO = (
    ('1', 'Recebida'),
    ('2', 'Aguardando resposta'),
    ('3','Solucionada'),
    ('4','Arquivada'),
)

TIPO_CONSULTA = (
    ('1', 'Consulta'),
    ('2', 'Exame'),
)

TIPO_CONTATO = (
    ('1', 'Igreja'),
    ('2', 'Liderança'),
    ('3', 'Amigo pessoal'),
)