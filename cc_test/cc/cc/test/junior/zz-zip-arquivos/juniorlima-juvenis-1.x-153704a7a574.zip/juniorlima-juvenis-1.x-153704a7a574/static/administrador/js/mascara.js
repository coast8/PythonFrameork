/**
 * Created with PyCharm.
 * User: Junior Lima
 * Date: 10/09/13
 * Time: 12:01
 * To change this template use File | Settings | File Templates.
 */

jQuery(function($){
   $("#id_telefone").mask("(99) 9999-9999");
});