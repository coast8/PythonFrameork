Install Sorl Thumbnails - Gerador de miniatura no Django
pip install sorl-thumbnail==12.0