from lib.sorl.thumbnail.fields import ImageField
from lib.sorl.thumbnail.shortcuts import get_thumbnail, delete

