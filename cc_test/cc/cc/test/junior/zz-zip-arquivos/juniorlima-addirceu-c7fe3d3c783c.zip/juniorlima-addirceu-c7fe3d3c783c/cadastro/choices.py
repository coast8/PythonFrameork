# -*- coding: utf-8 -*-
__author__ = 'juniorlima'

ESTADO_CIVIL = (('1', 'Solteiro'),('2', 'Casado'),('3', 'Separado'),('4', 'Divorciado'),('5', 'Viúvo'))

SITUACAO = (('1', 'Ativo'),('2', 'Mudou de congregação'),('3', 'Desviado'),('4', 'Falecido'))

SEXO = (
    ('1', 'Masculino'),
    ('2', 'Feminino'),
)
ESCOLARIDADE = (
    ('1', 'Fundamental'),
    ('2', 'Médio'),
    ('3', 'Superior'),
)