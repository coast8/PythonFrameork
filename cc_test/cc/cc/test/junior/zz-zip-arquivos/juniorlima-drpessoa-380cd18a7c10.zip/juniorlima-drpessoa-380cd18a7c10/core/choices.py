# -*- coding: utf-8 -*-
__author__ = 'juniorlima'

BLOG_POSTAGEM_POSICAO = (
    ('1', 'Padrão'),
    ('2', 'Imagem esquerda'),
    ('3', 'Imagem direita'),
)

PUBLICIDADES_TIPOS = (
    ('1','Cabeçalho - 728x90'),
    ('2','Retângulo Médio - 300x250'),
    ('3','Botão - 125x125')
)